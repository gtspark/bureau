import React from 'react';
import { Command, Wifi, Settings, Bell, Search, PanelLeft, Sidebar, LayoutGrid } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="h-10 border-b border-white/5 bg-zinc-900/80 backdrop-blur-md flex items-center justify-between px-3 select-none z-50 relative">
      {/* Left Section: Logo & Controls */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="bg-gradient-to-tr from-blue-600 to-cyan-500 p-1 rounded-lg shadow-lg shadow-blue-500/20 group-hover:shadow-blue-500/40 transition-all duration-300">
             <Command size={14} className="text-white" />
          </div>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-100 to-gray-400 font-bold tracking-tight group-hover:from-white group-hover:to-gray-300 transition-all">Bureau</span>
        </div>
        
        <div className="h-4 w-[1px] bg-white/10 mx-1"></div>

        <nav className="flex items-center gap-0.5 text-xs font-medium text-zinc-400">
          {['File', 'Edit', 'View', 'Go', 'Run', 'Terminal', 'Help'].map((item) => (
             <button key={item} className="hover:text-zinc-100 px-2 py-1 rounded-md hover:bg-white/5 transition-all duration-200">{item}</button>
          ))}
        </nav>
      </div>

      {/* Center: Command Palette Trigger */}
      <div className="flex-1 max-w-lg mx-4">
        <button className="w-full flex items-center justify-between bg-black/20 border border-white/5 rounded-lg text-xs px-3 py-1.5 text-zinc-400 hover:border-white/10 hover:bg-black/40 hover:text-zinc-200 transition-all duration-200 group shadow-inner">
          <div className="flex items-center gap-2">
            <Search size={12} className="group-hover:text-blue-400 transition-colors" />
            <span className="opacity-70 group-hover:opacity-100">Search files and commands...</span>
          </div>
          <div className="flex items-center gap-1">
            <kbd className="bg-white/5 border border-white/10 rounded px-1 min-w-[20px] text-center font-mono text-[10px]">⌘</kbd>
            <kbd className="bg-white/5 border border-white/10 rounded px-1 min-w-[20px] text-center font-mono text-[10px]">P</kbd>
          </div>
        </button>
      </div>

      {/* Right Section: Status & Actions */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-green-500/5 border border-green-500/10 hover:bg-green-500/10 transition-colors cursor-pointer group">
          <div className="relative w-1.5 h-1.5">
              <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-75"></div>
              <div className="relative w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.5)]"></div>
          </div>
          <span className="text-[10px] text-green-400 font-medium tracking-wide group-hover:text-green-300 transition-colors">CONNECTED</span>
        </div>
        
        <div className="h-4 w-[1px] bg-white/10 mx-1"></div>

        <div className="flex items-center gap-1">
            <button className="text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-white/5 rounded-md transition-all">
            <PanelLeft size={16} />
            </button>
            <button className="text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-white/5 rounded-md transition-all">
            <LayoutGrid size={16} />
            </button>
            <button className="text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-white/5 rounded-md transition-all">
            <Sidebar size={16} className="rotate-180" />
            </button>
        </div>
        
        <div className="h-4 w-[1px] bg-white/10 mx-1"></div>

        <button className="text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-white/5 rounded-md transition-all">
            <Bell size={16} />
        </button>
        <button className="text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-white/5 rounded-md transition-all">
            <Settings size={16} />
        </button>
        
        <div className="w-7 h-7 ml-2 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-700 shadow-lg shadow-indigo-500/20 flex items-center justify-center text-xs font-bold text-white cursor-pointer hover:shadow-indigo-500/40 hover:scale-105 transition-all duration-200 border border-white/10">
          JS
        </div>
      </div>
    </header>
  );
};