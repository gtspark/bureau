import React, { useState } from 'react';
import { Files, GitBranch, Search, Settings, Grid, Box } from 'lucide-react';
import { FileTree } from './FileTree';
import { GitStatus } from './GitStatus';
import { MOCK_FILE_TREE, MOCK_GIT_CHANGES } from '../constants';
import { FileNode } from '../types';
import { cn } from '../utils/cn';

type SidebarView = 'explorer' | 'search' | 'git' | 'extensions';

export const Sidebar: React.FC = () => {
  const [activeView, setActiveView] = useState<SidebarView>('explorer');
  const [fileTree, setFileTree] = useState<FileNode[]>(MOCK_FILE_TREE);

  const handleMoveNode = (draggedId: string, targetId: string) => {
    // Logic same as before...
    if (draggedId === targetId) return;

    setFileTree((prevTree) => {
      const newTree = JSON.parse(JSON.stringify(prevTree)) as FileNode[];
      let draggedNode: FileNode | null = null;
      
      const removeNode = (nodes: FileNode[]): FileNode[] => {
        const result: FileNode[] = [];
        for (const node of nodes) {
          if (node.id === draggedId) {
            draggedNode = node;
            continue;
          }
          if (node.children) {
            node.children = removeNode(node.children);
          }
          result.push(node);
        }
        return result;
      };

      const treeWithoutDragged = removeNode(newTree);

      if (!draggedNode) return prevTree; 

      const isTargetDescendant = (parent: FileNode, targetId: string): boolean => {
         if (!parent.children) return false;
         for (const child of parent.children) {
             if (child.id === targetId) return true;
             if (isTargetDescendant(child, targetId)) return true;
         }
         return false;
      }
      
      if (draggedNode.type === 'folder' && isTargetDescendant(draggedNode, targetId)) {
          return prevTree;
      }

      const insertNode = (nodes: FileNode[]): FileNode[] => {
        return nodes.flatMap((node) => {
          if (node.id === targetId) {
            if (node.type === 'folder') {
              return [{
                ...node,
                isOpen: true,
                children: [...(node.children || []), draggedNode!]
              }];
            } else {
              return [node, draggedNode!];
            }
          }
          if (node.children) {
            return [{
              ...node,
              children: insertNode(node.children)
            }];
          }
          return [node];
        });
      };

      return insertNode(treeWithoutDragged);
    });
  };

  return (
    <div className="flex h-full bg-transparent">
      {/* Activity Bar */}
      <div className="w-12 flex flex-col items-center py-3 bg-zinc-900/50 border-r border-white/5 gap-2 backdrop-blur-sm z-10">
        <ActivityIcon 
          icon={<Files size={22} strokeWidth={1.5} />} 
          active={activeView === 'explorer'} 
          onClick={() => setActiveView('explorer')} 
        />
        <ActivityIcon 
          icon={<Search size={22} strokeWidth={1.5} />} 
          active={activeView === 'search'} 
          onClick={() => setActiveView('search')} 
        />
        <ActivityIcon 
          icon={<GitBranch size={22} strokeWidth={1.5} />} 
          active={activeView === 'git'} 
          onClick={() => setActiveView('git')} 
          badge={MOCK_GIT_CHANGES.length}
        />
        <ActivityIcon 
          icon={<Box size={22} strokeWidth={1.5} />} 
          active={activeView === 'extensions'} 
          onClick={() => setActiveView('extensions')} 
        />
        <div className="flex-1" />
        <ActivityIcon 
          icon={<Settings size={22} strokeWidth={1.5} />} 
          active={false} 
          onClick={() => {}} 
        />
      </div>

      {/* Sidebar Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-transparent">
        <div className="h-10 px-5 flex items-center text-[10px] font-bold tracking-widest text-zinc-500 uppercase border-b border-white/5 select-none">
          {activeView === 'explorer' && 'Explorer'}
          {activeView === 'search' && 'Search'}
          {activeView === 'git' && 'Source Control'}
          {activeView === 'extensions' && 'Extensions'}
        </div>
        
        <div className="flex-1 overflow-y-auto animate-fade-in custom-scrollbar">
          {activeView === 'explorer' && (
            <div className="py-2">
              <div className="px-4 py-2 text-[10px] font-bold text-blue-400/80 mb-1 tracking-wider flex items-center justify-between group cursor-pointer hover:text-blue-400 transition-colors">
                <span>BUREAU-CLIENT</span>
                <span className="opacity-0 group-hover:opacity-100 transition-opacity text-zinc-500">...</span>
              </div>
              <FileTree nodes={fileTree} onMove={handleMoveNode} />
            </div>
          )}
          
          {activeView === 'git' && <GitStatus changes={MOCK_GIT_CHANGES} />}
          
          {activeView === 'search' && (
             <div className="p-6 text-center text-zinc-600 text-sm mt-10 italic">
               Search functionality stubbed.
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ActivityIcon = ({ 
  icon, 
  active, 
  onClick, 
  badge 
}: { 
  icon: React.ReactNode; 
  active: boolean; 
  onClick: () => void;
  badge?: number;
}) => (
  <button 
    onClick={onClick}
    className={cn(
        "relative w-9 h-9 flex items-center justify-center rounded-xl transition-all duration-300 group",
        active 
            ? "text-blue-400 bg-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.2)]" 
            : "text-zinc-500 hover:text-zinc-300 hover:bg-white/5"
    )}
  >
    {active && (
      <div className="absolute left-0 top-1/2 -translate-y-1/2 -ml-[1px] h-4 w-1 bg-blue-500 rounded-r-full shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
    )}
    
    <span className="relative z-10 transition-transform duration-300 group-hover:scale-110">
        {icon}
    </span>

    {badge !== undefined && badge > 0 && (
        <span className="absolute -top-1 -right-1 h-3.5 min-w-[14px] px-1 flex items-center justify-center text-[9px] font-bold text-white bg-blue-600 rounded-full border border-zinc-900 shadow-md">
            {badge}
        </span>
    )}
  </button>
);