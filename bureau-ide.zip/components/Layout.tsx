import React from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { EditorArea } from './EditorArea';
import { TerminalPane } from './TerminalPane';
import { ChatPanel } from './ChatPanel';
import { GitBranch, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';

const Handle = () => {
    return (
        <PanelResizeHandle className="w-1 bg-transparent hover:bg-blue-500/10 transition-colors flex items-center justify-center group focus:outline-none">
            <div className="w-[1px] h-full bg-white/5 group-hover:bg-blue-500/50 group-hover:shadow-[0_0_8px_rgba(59,130,246,0.6)] transition-all duration-300" />
        </PanelResizeHandle>
    )
}

const VerticalHandle = () => {
    return (
        <PanelResizeHandle className="h-1 bg-transparent hover:bg-blue-500/10 transition-colors flex items-center justify-center group focus:outline-none cursor-row-resize z-10">
            <div className="h-[1px] w-full bg-white/5 group-hover:bg-blue-500/50 group-hover:shadow-[0_0_8px_rgba(59,130,246,0.6)] transition-all duration-300" />
        </PanelResizeHandle>
    )
}

export const Layout: React.FC = () => {
  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-zinc-950 text-ide-text font-sans antialiased selection:bg-blue-500/30 selection:text-blue-100">
      <Header />
      
      <div className="flex-1 overflow-hidden relative z-0">
         {/* Subtle background glow for depth */}
         <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent pointer-events-none z-[-1]" />
         
        <PanelGroup direction="horizontal">
          
          {/* Sidebar */}
          <Panel defaultSize={20} minSize={15} maxSize={30} collapsible className="bg-zinc-900/50 backdrop-blur-sm border-r border-white/5">
            <Sidebar />
          </Panel>

          <Handle />

          {/* Main Content Area */}
          <Panel className="bg-zinc-950/80">
            <PanelGroup direction="vertical">
              {/* Editor */}
              <Panel defaultSize={70} minSize={30}>
                <EditorArea />
              </Panel>

              <VerticalHandle />

              {/* Terminal */}
              <Panel defaultSize={30} minSize={10} collapsible className="bg-[#0c0c0e] border-t border-white/5">
                <TerminalPane />
              </Panel>
            </PanelGroup>
          </Panel>

          <Handle />

          {/* Chat Panel */}
          <Panel defaultSize={25} minSize={20} maxSize={40} collapsible className="bg-zinc-900/80 backdrop-blur-md border-l border-white/5 shadow-2xl">
            <ChatPanel />
          </Panel>

        </PanelGroup>
      </div>
      
      {/* Footer Status Bar */}
      <footer className="h-6 bg-gradient-to-r from-blue-700 to-blue-600 text-white/90 flex items-center justify-between px-3 text-[10px] font-medium tracking-wide select-none shadow-lg z-20">
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <GitBranch size={10} />
                <span>main*</span>
            </div>
            <div className="flex items-center gap-3 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <div className="flex items-center gap-1">
                    <XCircle size={10} /> 0
                </div>
                <div className="flex items-center gap-1">
                    <AlertCircle size={10} /> 0
                </div>
            </div>
        </div>
        <div className="flex items-center gap-4">
             <div className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <span>Ln 12, Col 34</span>
            </div>
             <div className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <span>UTF-8</span>
            </div>
             <div className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <span className="text-blue-100 font-bold">TSX</span>
            </div>
             <div className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <CheckCircle2 size={10} /> 
                <span>Prettier</span>
            </div>
            <div className="hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
                <span className="w-2 h-2 rounded-full bg-blue-400 block shadow-[0_0_8px_rgba(96,165,250,0.8)]"></span>
            </div>
        </div>
      </footer>
    </div>
  );
};