import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Folder, FileCode, FileJson, File, FileText } from 'lucide-react';
import { FileNode } from '../types';
import { cn } from '../utils/cn';

interface FileTreeProps {
  nodes: FileNode[];
  depth?: number;
  onSelect?: (node: FileNode) => void;
  onMove?: (draggedId: string, targetId: string) => void;
}

const getFileIcon = (filename: string) => {
  if (filename.endsWith('.tsx') || filename.endsWith('.ts')) return <FileCode size={14} className="text-blue-400" />;
  if (filename.endsWith('.json')) return <FileJson size={14} className="text-yellow-400" />;
  if (filename.endsWith('.md')) return <FileText size={14} className="text-gray-400" />;
  if (filename.endsWith('.html')) return <FileCode size={14} className="text-orange-400" />;
  return <File size={14} className="text-zinc-400" />;
};

const FileTreeNode: React.FC<{ 
  node: FileNode; 
  depth: number; 
  onSelect?: (node: FileNode) => void;
  onMove?: (draggedId: string, targetId: string) => void;
}> = ({ node, depth, onSelect, onMove }) => {
  const [isOpen, setIsOpen] = useState(node.isOpen || false);
  const [isSelected, setIsSelected] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSelected(true);
    if (node.type === 'folder') {
      setIsOpen(!isOpen);
    } else {
      if (onSelect) onSelect(node);
      console.log(`Opened file: ${node.name}`);
    }
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation();
    // Set the dragged node ID
    e.dataTransfer.setData('application/bureau-node', node.id);
    e.dataTransfer.effectAllowed = 'move';
    
    // Add a ghost image opacity if needed, though browser default is usually fine
    // e.currentTarget.classList.add('opacity-50');
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault(); // Necessary to allow dropping
    e.stopPropagation();
    
    // Simple visual check: can't drop on itself
    // We can't check dataTransfer data here in some browsers due to security, 
    // so we rely on handleDrop for logic validation.
    setIsDragOver(true);
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    
    const draggedId = e.dataTransfer.getData('application/bureau-node');
    if (draggedId && draggedId !== node.id && onMove) {
      onMove(draggedId, node.id);
    }
  };

  return (
    <div className="select-none">
      <div 
        draggable
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          "flex items-center gap-1.5 py-0.5 px-2 cursor-pointer text-sm text-zinc-300 transition-colors border border-transparent",
          // Normal hover/active states
          !isDragOver && "hover:bg-zinc-800",
          isSelected && !isDragOver && "bg-blue-500/20 text-blue-100",
          // Drag over states
          isDragOver && node.type === 'folder' && "bg-blue-500/30 border-blue-500/50",
          isDragOver && node.type === 'file' && "bg-zinc-700 border-t-blue-500 border-t"
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        onClick={handleClick}
      >
        <span className="opacity-70 flex-shrink-0 w-4 h-4 flex items-center justify-center">
          {node.type === 'folder' && (
            isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />
          )}
        </span>
        
        <span className="flex-shrink-0">
            {node.type === 'folder' ? (
                <Folder size={14} className={cn("text-blue-400", isOpen ? "fill-blue-500/20" : "")} />
            ) : getFileIcon(node.name)}
        </span>

        <span className="truncate">{node.name}</span>
      </div>

      {isOpen && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeNode 
              key={child.id} 
              node={child} 
              depth={depth + 1} 
              onSelect={onSelect} 
              onMove={onMove}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export const FileTree: React.FC<FileTreeProps> = ({ nodes, onSelect, onMove }) => {
  return (
    <div className="flex flex-col py-1">
      {nodes.map((node) => (
        <FileTreeNode 
          key={node.id} 
          node={node} 
          depth={0} 
          onSelect={onSelect} 
          onMove={onMove}
        />
      ))}
    </div>
  );
};