import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, MoreHorizontal, X, Mic } from 'lucide-react';
import { MOCK_CHATS } from '../constants';
import { ChatMessage } from '../types';
import { cn } from '../utils/cn';

export const ChatPanel: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>(MOCK_CHATS);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages([...messages, newMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
        setIsTyping(false);
        setMessages(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: 'I\'ve updated the UI components as requested. The visual hierarchy is now clearer with the glassmorphic effects and subtle gradients.',
            timestamp: new Date()
        }]);
    }, 1500);
  };

  return (
    <div className="h-full flex flex-col bg-transparent">
      {/* Header */}
      <div className="h-10 px-4 flex items-center justify-between border-b border-white/5 bg-zinc-900/40 backdrop-blur-md shadow-sm">
        <div className="flex items-center gap-2 font-semibold text-zinc-100 text-xs tracking-wide">
          <div className="p-1 rounded bg-blue-500/10">
             <Sparkles size={12} className="text-blue-400" />
          </div>
          <span>CLAUDE ASSISTANT</span>
        </div>
        <div className="flex items-center gap-1 text-zinc-500">
           <button className="p-1.5 hover:text-zinc-300 hover:bg-white/5 rounded transition-colors"><MoreHorizontal size={14} /></button>
           <button className="p-1.5 hover:text-zinc-300 hover:bg-white/5 rounded transition-colors"><X size={14} /></button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar scroll-smooth">
        {messages.map((msg) => (
          <div key={msg.id} className={cn("flex gap-3 animate-slide-up group", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
            <div className={cn(
              "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-1 shadow-lg transition-transform duration-300 group-hover:scale-105",
              msg.role === 'assistant' 
                ? "bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-indigo-500/20" 
                : "bg-gradient-to-br from-zinc-700 to-zinc-600 text-zinc-300"
            )}>
              {msg.role === 'assistant' ? <Bot size={14} /> : <User size={14} />}
            </div>
            
            <div className={cn(
              "flex flex-col gap-1 max-w-[85%]", 
              msg.role === 'user' ? "items-end" : "items-start"
            )}>
              <div className="flex items-center gap-2 text-[9px] font-medium text-zinc-500 px-1 uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span>{msg.role === 'assistant' ? 'Claude' : 'You'}</span>
                <span>{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className={cn(
                "px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed shadow-md backdrop-blur-sm border",
                msg.role === 'user' 
                  ? "bg-blue-600 text-white border-blue-500 rounded-tr-sm" 
                  : "bg-zinc-800/80 text-zinc-200 border-white/5 rounded-tl-sm"
              )}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        
        {isTyping && (
             <div className="flex gap-3 animate-slide-up">
                 <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-1 bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/20">
                     <Bot size={14} />
                 </div>
                 <div className="bg-zinc-800/80 border border-white/5 px-4 py-3 rounded-2xl rounded-tl-sm flex gap-1 items-center">
                     <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                     <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                     <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                 </div>
             </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/5 bg-zinc-900/60 backdrop-blur-sm">
        <form onSubmit={handleSendMessage} className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl blur opacity-0 group-focus-within:opacity-100 transition-opacity duration-500"></div>
          <textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(e);
              }
            }}
            placeholder="Ask Claude to edit files or explain code..."
            className="relative w-full bg-zinc-950 border border-white/10 rounded-xl pl-4 pr-12 py-3 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 resize-none min-h-[56px] max-h-[120px] custom-scrollbar shadow-inner transition-all duration-200"
            rows={2}
          />
          <div className="absolute right-3 bottom-3 flex items-center gap-1">
             <button
               type="button"
                className="p-1.5 text-zinc-500 hover:text-zinc-300 rounded-md transition-colors"
             >
                <Mic size={14} />
             </button>
            <button 
                type="submit"
                className={cn(
                    "p-1.5 rounded-lg transition-all duration-300 shadow-lg",
                    inputValue.trim() 
                        ? "bg-blue-600 hover:bg-blue-500 text-white hover:scale-105 shadow-blue-500/30" 
                        : "bg-zinc-800 text-zinc-600 cursor-not-allowed"
                )}
                disabled={!inputValue.trim()}
            >
                <Send size={14} />
            </button>
          </div>
        </form>
        <div className="mt-2.5 flex items-center justify-between text-[9px] font-medium text-zinc-500 px-1">
           <div className="flex gap-3">
             <span className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1 rounded border border-white/5 font-sans">⏎</kbd> send</span>
             <span className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1 rounded border border-white/5 font-sans">⇧ ⏎</kbd> newline</span>
           </div>
           <span className="text-blue-500/60 font-semibold tracking-wide">CLAUDE 3.5 SONNET</span>
        </div>
      </div>
    </div>
  );
};