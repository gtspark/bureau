import React, { useState } from 'react';
import { X, Circle, FileCode } from 'lucide-react';
import { INITIAL_TABS, MOCK_CODE_CONTENT } from '../constants';
import { Tab } from '../types';
import { cn } from '../utils/cn';

export const EditorArea: React.FC = () => {
  const [tabs, setTabs] = useState<Tab[]>(INITIAL_TABS);

  const handleCloseTab = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setTabs(tabs.filter(t => t.id !== id));
  };

  const handleTabClick = (id: string) => {
    setTabs(tabs.map(t => ({ ...t, active: t.id === id })));
  };

  const activeTab = tabs.find(t => t.active);

  return (
    <div className="h-full flex flex-col bg-[#0c0c0e] relative z-0">
      {/* Tabs Container */}
      <div className="flex bg-[#121214] border-b border-white/5 overflow-x-auto no-scrollbar pt-1">
        {tabs.map(tab => (
          <div
            key={tab.id}
            onClick={() => handleTabClick(tab.id)}
            className={cn(
              "group relative flex items-center gap-2 px-3.5 py-2 min-w-[140px] max-w-[220px] cursor-pointer text-xs select-none transition-all duration-200 border-r border-white/5",
              tab.active 
                ? "bg-[#0c0c0e] text-blue-100 rounded-t-lg z-10" 
                : "bg-transparent text-zinc-500 hover:bg-[#18181b] hover:text-zinc-300"
            )}
          >
             {/* Active Top Highlight */}
             {tab.active && (
                 <div className="absolute top-0 left-0 right-0 h-[2px] bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
             )}

            <FileCode size={12} className={cn(tab.active ? "text-blue-400" : "opacity-50")} />
            
            <span className={cn("flex-1 truncate font-medium", tab.active ? "text-zinc-100" : "")}>
                {tab.title}
            </span>
            
            <span className="opacity-0 group-hover:opacity-100 transition-opacity">
              {tab.isDirty ? (
                <div className="w-2 h-2 rounded-full bg-blue-400/80 shadow-[0_0_4px_rgba(96,165,250,0.5)]" />
              ) : (
                <button 
                  onClick={(e) => handleCloseTab(e, tab.id)}
                  className="p-0.5 rounded-md hover:bg-white/10 text-zinc-400 hover:text-red-300 transition-colors"
                >
                  <X size={12} />
                </button>
              )}
            </span>
          </div>
        ))}
      </div>

      {/* Editor Content */}
      <div className="flex-1 relative bg-[#0c0c0e] overflow-hidden flex shadow-inner">
        {/* Line Numbers */}
        <div className="w-14 py-4 flex flex-col items-end px-3 text-zinc-700 text-xs font-mono select-none bg-[#0c0c0e] border-r border-white/5 z-10">
          {Array.from({ length: 25 }).map((_, i) => (
            <div key={i} className="leading-6 hover:text-zinc-500 transition-colors cursor-pointer">{i + 1}</div>
          ))}
        </div>

        {/* Code Area */}
        {activeTab ? (
          <div className="flex-1 py-4 font-mono text-sm leading-6 text-zinc-300 overflow-auto whitespace-pre selection:bg-blue-500/20 selection:text-blue-200 relative">
             {/* Subtle Glow behind code area for depth */}
             <div className="absolute inset-0 bg-gradient-to-br from-blue-900/5 to-transparent pointer-events-none" />
             
            {/* Syntax Highlighting Mock */}
            <div className="px-4 relative z-0" dangerouslySetInnerHTML={{ __html: MOCK_CODE_CONTENT
              .replace(/import/g, '<span class="text-purple-400 font-medium">import</span>')
              .replace(/from/g, '<span class="text-purple-400 font-medium">from</span>')
              .replace(/const/g, '<span class="text-blue-400 font-medium">const</span>')
              .replace(/return/g, '<span class="text-purple-400 font-medium">return</span>')
              .replace(/function/g, '<span class="text-blue-400 font-medium">function</span>')
              .replace(/export/g, '<span class="text-purple-400 font-medium">export</span>')
              .replace(/default/g, '<span class="text-purple-400 font-medium">default</span>')
              .replace(/'(.*?)'/g, '<span class="text-emerald-400">\'$1\'</span>')
              .replace(/\/\/(.*)/g, '<span class="text-zinc-500 italic">//$1</span>')
              .replace(/Layout/g, '<span class="text-yellow-200">Layout</span>')
              .replace(/App/g, '<span class="text-yellow-200">App</span>')
              .replace(/div/g, '<span class="text-red-300">div</span>')
            }} />
          </div>
        ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-zinc-600 bg-[#0c0c0e]">
                <div className="w-20 h-20 rounded-2xl bg-zinc-900/50 flex items-center justify-center mb-6 shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] border border-white/5 rotate-3">
                     <span className="text-4xl opacity-20 font-bold">⌘</span>
                </div>
                <p className="text-lg font-medium text-zinc-500">No file is open</p>
                <p className="text-xs text-zinc-700 mt-2">Use <kbd className="bg-zinc-900 px-1 py-0.5 rounded border border-zinc-800">⌘P</kbd> to search files</p>
            </div>
        )}
      </div>
      
      {/* Breadcrumbs */}
      <div className="h-7 bg-[#0c0c0e] border-t border-white/5 flex items-center px-4 text-xs text-zinc-500 gap-1.5 z-10 shadow-[0_-5px_10px_rgba(0,0,0,0.1)]">
        <span className="hover:text-zinc-300 cursor-pointer transition-colors">src</span>
        <span className="opacity-40">/</span>
        <span className="hover:text-zinc-300 cursor-pointer transition-colors">components</span>
        <span className="opacity-40">/</span>
        <span className="text-blue-400 font-medium flex items-center gap-1.5">
            <FileCode size={10} />
            {activeTab?.title || 'No file'}
        </span>
      </div>
    </div>
  );
};