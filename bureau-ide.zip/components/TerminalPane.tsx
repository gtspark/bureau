import React from 'react';
import { Terminal, Trash2, Maximize2, X, Plus, MoreHorizontal } from 'lucide-react';

export const TerminalPane: React.FC = () => {
  return (
    <div className="h-full flex flex-col bg-[#0c0c0e]">
      {/* Terminal Tabs/Header */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/5 bg-[#121214] select-none">
        <div className="flex items-center gap-6 text-[11px] font-medium tracking-wide">
          <button className="flex items-center gap-1.5 text-zinc-100 relative group">
            <span className="font-semibold text-blue-400">TERMINAL</span>
            <div className="absolute -bottom-[9px] left-0 right-0 h-[2px] bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)] rounded-t-full"></div>
          </button>
          <button className="text-zinc-500 hover:text-zinc-300 transition-colors">OUTPUT</button>
          <button className="text-zinc-500 hover:text-zinc-300 transition-colors">PROBLEMS</button>
          <button className="text-zinc-500 hover:text-zinc-300 transition-colors">DEBUG CONSOLE</button>
        </div>
        <div className="flex items-center gap-1 text-zinc-500">
           <div className="flex items-center gap-1 mr-2 px-1.5 py-0.5 rounded bg-white/5 border border-white/5">
                <Plus size={12} />
                <span className="text-[10px]">bash</span>
           </div>
          <button className="p-1 hover:text-zinc-200 hover:bg-white/5 rounded transition-colors"><Trash2 size={13} /></button>
          <button className="p-1 hover:text-zinc-200 hover:bg-white/5 rounded transition-colors"><Maximize2 size={13} /></button>
          <button className="p-1 hover:text-zinc-200 hover:bg-white/5 rounded transition-colors"><X size={13} /></button>
        </div>
      </div>

      {/* Terminal Content (Mock) */}
      <div className="flex-1 p-3 font-mono text-[13px] overflow-auto bg-[#09090b] text-zinc-300 scanline relative">
        <div className="opacity-50 mb-3 text-xs italic font-sans text-zinc-500 select-none">Last login: Today at 09:41 on ttys001</div>
        
        <div className="flex flex-col gap-1.5">
          <div className="flex gap-2 items-center">
            <span className="text-green-500 font-bold">➜</span>
            <span className="text-blue-400 font-semibold">~/projects/bureau</span>
            <span className="text-purple-400 bg-purple-500/10 px-1 rounded text-xs">git:(main)</span>
            <span className="text-zinc-100">npm install</span>
          </div>
          <div className="text-zinc-400 pl-5 text-xs opacity-80 leading-relaxed">
            <div className="flex gap-2"><span className="text-green-500">✓</span> added 142 packages</div>
            <div className="flex gap-2"><span className="text-green-500">✓</span> audited 143 packages in 2s</div>
            <div className="text-zinc-500 mt-1">found 0 vulnerabilities</div>
          </div>
          
          <div className="flex gap-2 items-center mt-2">
            <span className="text-green-500 font-bold">➜</span>
            <span className="text-blue-400 font-semibold">~/projects/bureau</span>
            <span className="text-purple-400 bg-purple-500/10 px-1 rounded text-xs">git:(main)</span>
            <span className="w-2.5 h-4 bg-zinc-400 animate-pulse block"></span>
          </div>
        </div>
      </div>
    </div>
  );
};