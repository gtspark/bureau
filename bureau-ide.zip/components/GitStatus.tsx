import React from 'react';
import { GitChange } from '../types';
import { Plus, Minus, FileDiff, Check } from 'lucide-react';

interface GitStatusProps {
  changes: GitChange[];
}

export const GitStatus: React.FC<GitStatusProps> = ({ changes }) => {
  const staged = changes.filter(c => c.staged);
  const unstaged = changes.filter(c => !c.staged);

  const StatusIcon = ({ status }: { status: string }) => {
    switch (status) {
      case 'modified': return <span className="text-yellow-500 text-xs font-mono">M</span>;
      case 'added': return <span className="text-green-500 text-xs font-mono">A</span>;
      case 'deleted': return <span className="text-red-500 text-xs font-mono">D</span>;
      case 'untracked': return <span className="text-gray-500 text-xs font-mono">U</span>;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-3 py-2 text-xs font-semibold text-zinc-400 flex justify-between items-center bg-zinc-900/50">
        <span>SOURCE CONTROL</span>
        <div className="flex gap-2">
            <Check size={14} className="hover:text-white cursor-pointer" />
            <Plus size={14} className="hover:text-white cursor-pointer" />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar p-1">
        {staged.length > 0 && (
          <div className="mb-4">
            <div className="px-2 py-1 text-xs font-medium text-zinc-500 uppercase flex items-center gap-1">
              <ChevronDown size={12} /> Staged Changes
            </div>
            {staged.map(change => (
              <div key={change.id} className="flex items-center gap-2 px-4 py-1 hover:bg-zinc-800 cursor-pointer text-sm text-zinc-300 group">
                <StatusIcon status={change.status} />
                <span className="truncate flex-1">{change.file}</span>
                <Minus size={14} className="opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-zinc-200" />
              </div>
            ))}
          </div>
        )}

        <div>
           <div className="px-2 py-1 text-xs font-medium text-zinc-500 uppercase flex items-center gap-1">
              <ChevronDown size={12} /> Changes
            </div>
          {unstaged.map(change => (
            <div key={change.id} className="flex items-center gap-2 px-4 py-1 hover:bg-zinc-800 cursor-pointer text-sm text-zinc-300 group">
              <StatusIcon status={change.status} />
              <span className="truncate flex-1">{change.file}</span>
              <Plus size={14} className="opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-zinc-200" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Helper component for local use
const ChevronDown = ({ size }: { size: number }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} 
        height={size} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
    >
        <path d="m6 9 6 6 6-6"/>
    </svg>
);
