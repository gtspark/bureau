import { FileNode, GitChange, ChatMessage, Tab } from './types';

export const MOCK_FILE_TREE: FileNode[] = [
  {
    id: 'root',
    name: 'bureau-client',
    type: 'folder',
    isOpen: true,
    children: [
      {
        id: 'src',
        name: 'src',
        type: 'folder',
        isOpen: true,
        children: [
          {
            id: 'components',
            name: 'components',
            type: 'folder',
            isOpen: false,
            children: [
              { id: 'App.tsx', name: 'App.tsx', type: 'file' },
              { id: 'Header.tsx', name: 'Header.tsx', type: 'file' },
              { id: 'Sidebar.tsx', name: 'Sidebar.tsx', type: 'file' },
            ]
          },
          { id: 'index.tsx', name: 'index.tsx', type: 'file' },
          { id: 'utils.ts', name: 'utils.ts', type: 'file' },
        ]
      },
      {
        id: 'public',
        name: 'public',
        type: 'folder',
        children: [
          { id: 'index.html', name: 'index.html', type: 'file' },
          { id: 'manifest.json', name: 'manifest.json', type: 'file' },
        ]
      },
      { id: 'package.json', name: 'package.json', type: 'file' },
      { id: 'tsconfig.json', name: 'tsconfig.json', type: 'file' },
      { id: '.gitignore', name: '.gitignore', type: 'file' },
    ]
  }
];

export const MOCK_GIT_CHANGES: GitChange[] = [
  { id: '1', file: 'src/components/App.tsx', status: 'modified', staged: true },
  { id: '2', file: 'src/utils.ts', status: 'modified', staged: false },
  { id: '3', file: 'public/logo.svg', status: 'added', staged: false },
  { id: '4', file: 'README.md', status: 'deleted', staged: false },
];

export const MOCK_CHATS: ChatMessage[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Welcome to Bureau. I\'m connected to the Claude Code CLI. How can I help you today?',
    timestamp: new Date(Date.now() - 1000 * 60 * 60)
  },
  {
    id: '2',
    role: 'user',
    content: 'Can you help me refactor the sidebar component to support drag and drop?',
    timestamp: new Date(Date.now() - 1000 * 60 * 30)
  },
  {
    id: '3',
    role: 'assistant',
    content: 'I can certainly help with that. Are we using any specific library for drag and drop interactions, like `dnd-kit` or `react-beautiful-dnd`?',
    timestamp: new Date(Date.now() - 1000 * 60 * 29)
  }
];

export const INITIAL_TABS: Tab[] = [
  { id: 'tab1', title: 'App.tsx', path: 'src/components/App.tsx', active: true, isDirty: false },
  { id: 'tab2', title: 'utils.ts', path: 'src/utils.ts', active: false, isDirty: true },
  { id: 'tab3', title: 'types.ts', path: 'src/types.ts', active: false, isDirty: false },
];

export const MOCK_CODE_CONTENT = `import React, { useState } from 'react';
import { Layout } from './components/Layout';

export default function App() {
  const [theme, setTheme] = useState('dark');

  // Initialize the application shell
  return (
    <div className="min-h-screen bg-ide-bg text-ide-text font-sans">
      <Layout />
    </div>
  );
}`;
